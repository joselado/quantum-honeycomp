# This script generates a script for performing the compilation of
# of the parts written in fortran


# PART TO EDIT
#################################################
#################################################
# options for the creation of the compilation script 
compiler = "gfortran"  # compiler used
options = "-O3 "  # full optimization
#options = "-O3 -fbounds-check"  # full optimization
lapack = "-llapack"  # lapack library flag
#################################################
#################################################



# The following doesn't have to be edited!!!
#################################################
#################################################
#################################################
#################################################
#################################################
#################################################
#################################################
#################################################
#################################################
#################################################
#################################################
#################################################
direction = "src"  # direction where the files are


import os 
from os.path import isfile, join
os.chdir(direction)

# get all the files
pwd = os.getcwd()

files = os.listdir(pwd)

# retain the .f90 files
allf90 = []
for f in files:
  end = f.split(".")
  if end[-1]=="f90":
      allf90.append(f)

# f90 files, ordered according to compilation

# remove from the whole list
taskf90 = []
taskf90 += ["density_of_states.f90"]
taskf90 += ["berry.f90"]
taskf90 += ["dielectric_response.f90"]


for f in taskf90:
  allf90.remove(f)




# first files
f90 = ["io_files.f90"]
f90 += ["inputs.f90"]
f90 += ["sparse.f90"]
f90 += ["system_variables.f90"]
f90 += ["expectation_values_variables.f90"]
f90 += ["sintax_hamiltonian.f90"]
#f90 += ["dielectric_operators.f90"]

# f90 variables
varf90 = []
for f in allf90:
  if "variables" in f:
    varf90.append(f)
# remove from the whole list
for f in varf90:
  allf90.remove(f)

allf90 = varf90 + allf90 + taskf90

allf90.remove("tb90.f90")

f90 += allf90

fc = open("compilation.sh","w")

# remove old files
fc.write("rm *.o\n")
fc.write("rm *.mod\n")


# compile each file
for f in f90:
  fc.write(compiler+" "+options+"  -c "+f+" "+lapack+"\n")


fc.write(compiler+" "+options+" -o tb90.x *.f90 "+lapack+"\n")


fc.close()
os.system("chmod +x compilation.sh")
os.system("rm *.mod")



