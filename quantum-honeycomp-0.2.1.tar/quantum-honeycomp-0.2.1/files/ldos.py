# library o calculate local density of states in a smart way

def finite_list(h):
  """Calcuates the ldos having as input a list of 1d hamiltonians"""



